package com.example.apple.WesternArt;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import com.example.apple.WesternArt.R;

/**
 * Created by apple on 1/17/17.
 */
public class DetailActivity extends AppCompatActivity {

    TextView tv;
    protected SQLiteDatabase db;
    SQLiteHelper dbHelper;
    private TextView authorTextView, captionTextView;
    private WebView wv;
    int position;
    int num = 0;
    String s1 = null, s2 = null, s3 = null, s4 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        Intent intent = this.getIntent();
        position = intent.getIntExtra("pos", -1) + 1;

        // DBのversionを変えるとOnUpgradeメソッドが呼ばれて，ソースコード上での修正が有効になる
        // SQLiteHelperのstatic final int VERSIONも同じ値に変える必要有り
        dbHelper = new SQLiteHelper(this, "data.db", null, 13);
        db = dbHelper.getWritableDatabase();

        String query = "select rowid as _id, name, author, image, caption from paintings where _id = " + position + ";";

        Cursor c = db.rawQuery(query, null);

        while(c.moveToNext()) {
            num = c.getInt(c.getColumnIndex("_id"));
            s1 = c.getString(c.getColumnIndex("name")) + "\n";
            s2 = c.getString(c.getColumnIndex("author")) + "\n";
            s3 = c.getString(c.getColumnIndex("image")) + "\n";
            s4 = c.getString(c.getColumnIndex("caption")) + "\n";
        }
        c.close();

        //ウィンドウタイトルを絵画の名前に変更
        setTitle(s1);

        wv = (WebView)findViewById(R.id.webView);

        // ページ全体を表示する(引用: http://d.hatena.ne.jp/black-vinegar/20120305/p1)
        wv.getSettings().setUseWideViewPort(true);
        wv.getSettings().setLoadWithOverviewMode(true);

        wv.loadUrl(s3);

        authorTextView = (TextView)findViewById(R.id.textView2);
        authorTextView.setText("作者: " + s2);

        captionTextView = (TextView)findViewById(R.id.caption);
        captionTextView.setText(s4);
    }
    public void onClick(View v) {
        finish();
    }
}
