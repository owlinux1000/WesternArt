package com.example.apple.WesternArt;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import com.example.apple.WesternArt.R;

public class MainActivity extends AppCompatActivity {

    ListView listView1;
    private View view;
    protected SQLiteDatabase db;
    protected ListAdapter adapter;
    String name, author, image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listView1 = (ListView)findViewById(R.id.list1);
        SQLiteHelper mDBHelper = new SQLiteHelper(this);
        SQLiteDatabase db = mDBHelper.getWritableDatabase();

        Cursor c = db.rawQuery("select rowid as _id, name, author, image, caption from paintings", null);

        String[] from = {"name"};
        int[] to = {R.id.textViewForList};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.list_item, c, from, to, 0);
        listView1.setAdapter(adapter);

        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("pos", position);
                startActivity(intent);
            }
        });

    }

}
