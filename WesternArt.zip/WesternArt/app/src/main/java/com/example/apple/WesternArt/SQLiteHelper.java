package com.example.apple.WesternArt;
import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by apple on 1/17/17.
 */
public class SQLiteHelper extends SQLiteOpenHelper {
    static final private String DBNAME="data.db";
    static final int VERSION=13;

    public SQLiteHelper(Context context,
                        String name,
                        SQLiteDatabase.CursorFactory factory,
                        int version) {
        super(context, name, factory, version);

    }


    public SQLiteHelper(Context context) {
        super(context, DBNAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table paintings(name text primary key, author text, image text, caption text)");

        db.execSQL("insert into paintings values('モナ・リザ'," +
                " 'レオナルド・ダ・ヴィンチ'," +
                " 'http://www.wallpaperlink.com/images/wallpaper/2007/0705/03414x.jpg'," +
                " 'モナ・リザは，イタリアの美術家レオナルド・ダ・ヴィンチが描いた油彩画．上半身のみが描かれた女性の肖像画で，世界でもっとも知られた，もっとも見られた，もっとも書かれた，もっとも歌われた，もっともパロディ作品が作られた美術作品である．')");

        db.execSQL("insert into paintings values('ヴィーナスの誕生'," +
                " 'サンドロ・ボッティチェリ'," +
                " 'https://www.be-en.co.jp/upload/save_image/M71-846.jpg'," +
                " '『ヴィーナスの誕生』 は，ルネッサンス期のイタリアの画家サンドロ・ボッティチェッリの作品で，キャンバス地に描かれたテンペラ画である．縦172.5cm，幅278.5cmの大作で，現在，フィレンツェのウフィッツィ美術館が所蔵し，展示している．')");

        db.execSQL("insert into paintings values('バベルの塔'," +
                " 'ピーテル・ブリューゲル1世'," +
                " 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Pieter_Bruegel_the_Elder_-_The_Tower_of_Babel_%28Vienna%29_-_Google_Art_Project.jpg/1280px-Pieter_Bruegel_the_Elder_-_The_Tower_of_Babel_%28Vienna%29_-_Google_Art_Project.jpg'," +
                " 'バベルの塔は，旧約聖書の「創世記」中に登場する巨大な塔． 神話とする説が支配的だが，一部の研究者は紀元前6世紀のバビロンのマルドゥク神殿に築かれたエ・テメン・アン・キのジッグラトの遺跡と関連づけた説を提唱する．')");

        db.execSQL("insert into paintings values('大工の聖ヨセフ'," +
                " 'ジョルジュ・ド・ラ・トゥール'," +
                " 'http://livedoor.blogimg.jp/nkurabay373/imgs/d/c/dc0f4491.jpg', " +
                " 'この『大工の聖ヨセフ』とはもちろんキリストの父ヨセフのこと．とすれば，右側の少女のような子どもは少年キリストであり，ヨセフが細工している角材は，やがてキリストが架けられる十字架を暗示しているに違いない．画面の大部分を占める漆黒の聞から，ろうそくの明かりが父子の姿を浮かび上がらせる．少年の無邪気そうな顔や，炎にかざして赤く透けた無垢な手に比べ，わが子の将来を予感したのだろうか，ヨセフの深刻そうな額の披や力のこもった腕が対照的だ．')");

        db.execSQL("insert into paintings values('夜警'," +
                " 'レンブラント'," +
                " 'http://www.artmuseum.jpn.org/yakei8.jpg', " +
                " '夜警は，オランダの17世紀の画家レンブラント・ファン・レインによる絵画作品の通称．この作品は18世紀以降この通称で呼ばれているが，より適切な題名は『フランス・バニング・コック隊長とウィレム・ファン・ラウテンブルフ副隊長の市民隊』となる．')");

        db.execSQL("insert into paintings values('真珠の耳飾りの少女'," +
                " 'フェルメール'," +
                " 'http://www.artmuseum.jpn.org/parl2.jpg', " +
                " '『真珠の耳飾りの少女』は，オランダの画家 ヨハネス・フェルメールの絵画であり，彼の代表作の一つ．『青いターバンの少女』・『ターバンを巻いた少女』とも呼ばれ，オランダのデン・ハーグのマウリッツハイス美術館が所蔵する．')");

        db.execSQL("insert into paintings values('グランドジャット島の日曜日の午後'," +
                " 'スーラ'," +
                " 'http://livedoor.blogimg.jp/kokinora/imgs/d/9/d9b87b7a.jpg'," +
                " '『グランド・ジャット島の日曜日の午後』 は19世紀末フランスの新印象派の画家ジョルジュ・スーラの代表作．点描法を用いて，パリ近郊のセーヌ川の中州で夏の一日を過ごす人々を描いた大作で，新印象派，ポスト印象派の時代のフランス絵画を代表する作品でもある．')");

        db.execSQL("insert into paintings values('ムーラン・ド・ラ・ギャレット'," +
                " 'ピエールオーギュスト・ルノワール'," +
                " 'http://hugonoblog.com/wp-content/uploads/2016/02/Bal-du-moulin-de-la-Galette-1.jpg', " +
                " '『ムーラン・ド・ラ・ギャレット』は，ルノワールが35歳のときに描いた絵画作品．1877年の第3回印象派展に出品された作品でもある．題名のムーラン・ド・ラ・ギャレットは，パリのモンマルトルにあるダンスホールの名．画中の人物たちは，彼の友人たちがモデルになっている．')");

        db.execSQL("insert into paintings values('受胎告知'," +
                " 'フラ・アンジェリコ'," +
                " 'http://www.artmuseum.jpn.org/jyutaikokuti.jpg'," +
                " '15世紀フィレンツェ派を代表する画家フラ・アンジェリコの傑作『受胎告知』。国際ゴシック様式的な豪華で優美な特徴と、鮮やかで輝きに満ちた色彩による画家独自の敬虔で高潔な人物描写が秀逸な本作の主題は、大天使ガブリエルによる聖母マリアへの聖胎の告知を描いた≪受胎告知≫で、フラ・アンジェリコは、生涯のうちに幾度も本主題を描いているが、最近、修復作業が完了した本作は、その最高傑作として名高い。')");

        db.execSQL("insert into paintings values('アルルの跳ね橋'," +
                " 'ゴッホ'," +
                " 'http://chachacha-mama.up.n.seesaa.net/chachacha-mama/image/A5A2A5EBA5EBA4CEA4CFA4CDB6B65B15D.jpg?d=a1'," +
                " 'オランダ本国や海外では「アルルのラングロワ橋」と呼ばれる．モデルとなったラングロワ橋はアルルの中心部から南西約3キロほどの運河に実際に架かっていたものだが，1930年にコンクリート橋にかけ替えられたため現存しない．跳ね橋は別の場所に再現され，「ファン・ゴッホ橋」と名付けられたが，運河の堤などの風景が異なるために，作品の雰囲気が再現されているわけではない．ゴッホはこの橋を題材に他にも5枚の絵を書いている他，数枚の素描を残している．')");

        db.execSQL("insert into paintings values('印象，日の出'," +
                " 'クロード・モネ'," +
                " 'http://www.vogue.co.jp/uploads/media/2015/09/16/09.jpg?1442402964', " +
                " '『印象・日の出』は，クロード・モネが1872年に描いた絵画であり，印象派の名前の由来ともなっている． フランス北西部の都市ル・アーヴルの港の風景をやわらかい筆の動きで描いている．')");

        db.execSQL("insert into paintings values('接吻'," +
                " 'クリムト'," +
                " 'http://img-cdn.jg.jugem.jp/b1f/483435/20090828_502922.jpg', " +
                " '接吻は，帝政オーストリアの画家グスタフ・クリムトが1907年から1908年にかけて描いた油絵．180 × 180 cm，キャンバスに油彩．現在はベルヴェデーレ宮殿オーストリア絵画館に収蔵されている． クリムト自身と恋人エミーリエ・フレーゲがモデルとされる．')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists paintings");
        onCreate(db);
    }
}
